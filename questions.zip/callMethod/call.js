let p1 = {
    name: "suresh",
    age: 18,
    // printFullName: function(){
    //     console.log(`This is ${this.name} and ${this.age}`);
    // }
}

printFullName =  function(hometown, state){
    console.log(`This is ${this.name} and ${this.age} and ${hometown} in the state ${state}`);
}
console.log(printFullName.call(p1, 'mumbai', 'Maharashtra'));

const obj1 = {
    name: "John",
    greet() {
        console.log(`Hello, ${this.name}`);
    }
};

const obj2 = { name: "Jane" };

// Borrow greet() from obj1
obj1.greet.call(obj2); // Output: Hello, Jane

function Animal(type) {
    this.type = type;
}

// Inheritance in JavaScript
function Dog(type, name) {
    Animal.call(this, type); // Inherit type property
    this.name = name;
}

const myDog = new Dog("Mammal", "Buddy");
console.log(myDog);// Output: { type: 'Mammal', name: 'Buddy' }


//Reusable Functions
function calculateTotalTax(rate) {
    return this.income * rate;
}

const person1 = { income: 50000 };
const person2 = { income: 70000 };

console.log(calculateTotalTax.call(person1, 0.2)); // Output: 10000
console.log(calculateTotalTax.call(person2, 0.2)); // Output: 14000

//Dynamic Context Binding
function logDetails() {
    console.log(`Name: ${this.name}, Age: ${this.age}`);
}

const user1 = { name: "Alice", age: 25 };
const user2 = { name: "Bob", age: 30 };

logDetails.call(user1); // Output: Name: Alice, Age: 25
logDetails.call(user2); // Output: Name: Bob, Age: 30

