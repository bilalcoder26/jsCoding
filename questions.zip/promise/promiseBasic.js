let promise = new Promise(function(resolve, reject) {
    setTimeout(()=>{resolve('done')},2000)
})

// promise.then(
//     result => console.log(result), // shows "done!" after 1 second
//     error => console.log(error) // doesn't run
//   );

  //error 

  let promise2 = new Promise(function(resolve, reject) {
    // setTimeout(() => reject(new Error("Whoops!")), 1000);
  })

//   promise2.then(
//     result => console.log(result), // doesn't run
//     error => console.log(error)
//   );

let promise3= new Promise((resolve, reject) => {
    setTimeout(() => resolve("value"), 2000);
  })
    .finally(() => console.log("Promise ready")) // triggers first
    .then(result => console.log(result));

    console.log("Promise with finally", promise3);
    /*

    because finally is not meant to process a promise result. As said, 
    it’s a place to do generic cleanup, no matter what the outcome was.
    */