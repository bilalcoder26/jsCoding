new Promise(function(resolve, reject) {
    setTimeout(() => resolve(1),1000)
}).then(function(result){
    console.log('result1', result)
    return new Promise(function(resolve, reject){
        setTimeout(() => resolve(result * 2), 1000);
    })
}).then(function(result){
    console.log('result2', result)
    return new Promise(function(resolve, reject){
        setTimeout(() => resolve(result * 2), 1000);
    })
}).then(function(result){
    console.log('result3', result)
})