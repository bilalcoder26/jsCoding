function isPrime(num){
    if(num === 1) return true;
    return num%2 !== 0 
}
console.log("isPrime",isPrime(5));
console.log("isPrime",isPrime(4));