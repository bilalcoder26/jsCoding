//fibonacci(2) = [0,1]
//fibonacci(3) = [0,1,1]
//fibonacci(7) = [0,1,1,2,3,5,8]

function fibonacci(num) {
    const fib = [0, 1];
    for(let i=2; i<num; i++){
        fib[i] = fib[i-1] + fib[i-2]
    }
    return fib
}
console.log('fib(2)', fibonacci(2));
console.log('fib(3)',fibonacci(3));
console.log('fib(4)', fibonacci(7));