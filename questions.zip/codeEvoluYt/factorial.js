//factorial of zero is 1
//factorial(4) = 4*3*2*1 = 24

const factorial =(num) => {
    let result  = 1;
    if (num < 0 ) return 'non -negative number not allowed';
    for(let i= 2; i<= num; i++){
        result = result * i;
        console.log('i', i, 'num', num, 'result', result)

    }
    return result;

}

console.log('factorial', factorial(5));
// console.log('factorial', factorial(0));
// console.log('factorial', factorial(-1));