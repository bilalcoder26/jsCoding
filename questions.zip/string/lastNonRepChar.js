let IpStr ="aagcddeeefchcgg"
// a=2
// g=3
// c=3
// d=2f=1,h=1
// output = h

function findLastNonRepChar(str) {
    let map ={};
    for(let char of str){
        map[char] = (map[char] || 0 ) + 1
    }
    // console.log(map);
    for(let i= str.length-1; i>=0; i--){
        if(map[str[i]] ===1){
            return str[i];
        }
    }

}

console.log(findLastNonRepChar(IpStr));