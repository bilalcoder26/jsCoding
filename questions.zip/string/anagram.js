// "hello" -> "lleoh" --> true
// "hello" -> "llloh" --> false
// "hello" -> "leohl" --> true

function isAnagram(string1, string2) {
    if (string1.length !== string2.length){
        return false;
    }
    let countString ={};
    for(const letter of string1){
        countString[letter] = (countString[letter] || 0) + 1;
    }
    console.log('countString', countString);
    for(const item of string2){
        if(!countString[item]){
            return false;
        }
        countString[item] -= 1;
    }
    // console.log('Object.values(countString)', Object.values(countString))
    return Object.values(countString).every(count => count === 0);

}

console.log(isAnagram('hello', 'lleoh'));
console.log(isAnagram('hello', 'llleoh'));
console.log(isAnagram('hello', 'lloh'));
console.log(isAnagram('hello', 'lohel'));