function capitailize(str){
    const result = str.split(" ").map((word)=>{
      return  word.charAt(0).toUpperCase() + word.substring(1)
    })
    return result.join(" ")
}

console.log(capitailize("harsh bhai kaise ho"))