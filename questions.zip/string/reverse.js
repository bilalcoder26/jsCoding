function reverseStr(str){
    return str.split('').reverse().join('')

}

console.log(reverseStr("samshad"));

function reverseSentence(sentence){
    const savedStr = sentence.split(' ').map((word)=>{ 
       return  word.split('').reverse().join('')
    })
   return savedStr.join(' ')

}
console.log(reverseSentence("samshad is good boy"));
console.log(reverseSentence("samshad"));