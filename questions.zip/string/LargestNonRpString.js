//write code for max length non repeated char substring

let Ipstr = "GeeksforGeeks";

function findLargestNonRpSubstring(str){
    let start =0;
    let end = 0;
    let maxLength =0;
    let substr = new Set();
    while(end < str.length){
        if(!substr.has(str[end])){
            substr.add(str[end]);
            maxLength = Math.max(maxLength,substr.size)
            console.log(substr.values())
            end++;
        }else{
            substr.delete(str[start]);
            start++;
        }

    }

    return maxLength

}


console.log(findLargestNonRpSubstring(Ipstr));