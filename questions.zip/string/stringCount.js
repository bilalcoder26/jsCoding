function stringCount(str){
    let countObj = {};
    str.split('').forEach(element => {
        if(countObj.hasOwnProperty(element) === false){
            countObj[element] = 1
        }else{
            countObj[element]++;
        }
        
    });
    return countObj


}
console.log('countObj("samshadali")', stringCount("samshadali"))