function outer() {
    function inner() {
        for (var i = 0; i < 3; i++) {
            setTimeout(
                (currentValue) => {
                    console.log(currentValue);
                },
                1000,
                i // Pass `i` as an argument
            );
        }
    }
    inner();
}

outer();