console.log("sdcsdc")
Promise.resolve(() => {
    return "data"
}).then((data) => {
    console.log(data)
});