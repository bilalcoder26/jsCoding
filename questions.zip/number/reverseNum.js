function reverse(num){
   return Number(num.toString().split('').reverse().join(''))
}
console.log(reverse(12345));

function reverseLoop(num){
    let result = 0;
    while(num > 0){
        let rem = num%10;
        result = result*10 + rem;
        num  = Math.floor(num/10);
    }
    return result;
}
console.log(reverseLoop(123457890));