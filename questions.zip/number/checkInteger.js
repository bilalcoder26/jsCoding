let a = 12.5;

if(a % 1 === 0){
    console.log("integrr")
}else{
    console.log("!integer")
}

console.log(Number.isInteger(12.4))
console.log(Number.isInteger(12))