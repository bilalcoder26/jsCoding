/**
 * @param {string} s
 * @return {string}
 */
var reverseString = function(s) {
  var length = s.length;
  var newString = '';
  for (var i=length - 1; i>=0; i--) {
    newString += s[i];
  }
  return newString;
};