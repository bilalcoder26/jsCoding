const isBelowThreshold = (currentValue) => currentValue < 40;

const array1 = [1, 30, 39, 29, 10, 13];

console.log(array1.every(isBelowThreshold));

Array.prototype.MyEvery = function(callback) {
    if(typeof callback !== 'function'){
        throw Error('callback function must be a function');
    }
    const arr = this;
    for(let i = 0; i < arr.length; i++){
        const result = callback(arr[i], i, arr);
        if(!result){
            return false;
        }
    }
    return true;

}

console.log(array1.MyEvery(isBelowThreshold));

