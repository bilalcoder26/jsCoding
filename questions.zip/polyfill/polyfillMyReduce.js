const array1 = [1, 2, 3, 4];

// 0 + 1 + 2 + 3 + 4
const initialValue = 0;
const sumWithInitial = array1.reduce(
  (accumulator, currentValue) => accumulator + currentValue,
  initialValue,
);

console.log(sumWithInitial);

Array.prototype.MyReduce = function (callback, initialValue) {
    if (typeof callback !== 'function') {
        throw new Error('Callback must be a function');
    }

    const arr = this;
    let accumulator;
    let startIndex = 0;

    if (arguments.length > 1) {
        // If initialValue is provided, use it as the starting accumulator
        accumulator = initialValue;
    } else {
        // If initialValue is not provided, use the first element as the accumulator
        if (arr.length === 0) {
            throw new TypeError('Reduce of empty array with no initial value');
        }
        accumulator = arr[0];
        startIndex = 1; // Start from the second element
    }

    for (let i = startIndex; i < arr.length; i++) {
        accumulator = callback(accumulator, arr[i], i, arr);
    }

    return accumulator;
};


const sumWithInitial2 = array1.MyReduce(
    (accumulator, currentValue) => accumulator + currentValue,
    initialValue,
  );
  
  console.log(sumWithInitial2);