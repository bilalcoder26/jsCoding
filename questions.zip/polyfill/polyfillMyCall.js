function Animal(type) {
    this.type = type;
}
function Dog(type, name) {
    Animal.call(this, type); // Inherit type property
    this.name = name;
}

const myDog = new Dog("Mammal", "Buddy");
console.log(myDog);