let arr = [2,5,63,89,3,56]
// arr.forEach((item, index) => console.log(`index, ${index} item: ${item}`));

Array.prototype.MyForEach = function(callback){
    if(typeof callback !== 'function') {
        throw Error('function callback must be a function')
    }
    const arr = this;
    // console.log(arr)
    for (let i = 0; i < arr.length; i++){
        callback(arr[i],i,arr);
    }
}

arr.MyForEach((item, index) => console.log(`index, ${index} item: ${item * 2}`));
// arr.MyForEach();