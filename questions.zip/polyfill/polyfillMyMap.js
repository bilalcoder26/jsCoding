let arr = [2,5,63,89,3,56]
// arr.map((item) => console.log(item));
let obj = [
    {name: 'foo', value: 'bar'},
    {name: 'tooth', value: 'ch'},
    {name: 'dsd', value: 'asca'}
]


Array.prototype.myMap = function(callback) {
    if(typeof callback !== 'function'){
        throw Error("function callback must be a function");
    }
    const arr = this;
    const newArray = [];
    for(let i = 0; i < arr.length; i++) {
        const result = callback(arr[i], i, arr);
        newArray.push(result);
    }
    return newArray;

}
// arr.myMap((item) => console.log(item));
// obj.myMap((item) => console.log(item?.name));

var a =10;
function myfun(){

    console.log(this)
    console.log(a)
    // return 3
}
// myfun();

// const obj1 = {
//     fun1: myfun(),
//     a:10,
// }
const obj2 = {
    fun1: myfun,
    a:10,
}
// console.log(obj1)
console.log('ob2', obj2.fun1())
// obj1.fun1;//undefined

// obj1.fun1();

// myfun.call(obj1)

// const newFun = myfun.bind(obj1);
// newFun();


