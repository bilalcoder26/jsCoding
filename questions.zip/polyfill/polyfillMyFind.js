let arr = [2,5,63,89,3,56]
const result = arr.find((item) => item <0);
console.log(result);

Array.prototype.MyFind = function(callback) {
    if(typeof callback !== 'function'){
        throw Error('callback must be a function');
    }
    const arr = this;
    for(let i = 0; i < arr.length; i++){
        const result = callback(arr[i], i, arr);
        if(result){
            return arr[i];
        }

    }
    return undefined;
}

const ans= arr.MyFind((item) => item < 0);
console.log(ans);