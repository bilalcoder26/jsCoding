let arr = [2,5,63,89,3,56]
const result = arr.filter((item) => item <56);
// console.log(result);

Array.prototype.MyFilter = function(callback) {
    if(typeof callback !== 'function'){
        throw Error("function callback must be a function");
    }
    const arr = this;
    const newArray = [];
    for(let i = 0; i < arr.length; i++){
        const result = callback(arr[i], i, arr);
        if(result){
            newArray.push(arr[i]);
        }

    }
    return newArray;

}

const ans = arr.MyFilter((item) => item > 56);
console.log(ans);


