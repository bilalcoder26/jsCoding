const array = [1, 2, 3, 4, 5];

// Checks whether an element is even
const even = (element) => element % 2 === 0;

// console.log(array.some(even))

Array.prototype.MySome = function(callback){
    if(typeof callback !== 'function'){
        throw Error('callback must be a function');
    }
    const arr = this;
    for(let i = 0; i < arr.length; i++){
        const result = callback(arr[i], i, arr);
        if(result){
            return true;
        }
    }
    return false;
}

const even2 = (element) => element % 2 === 0;

console.log("MysOME", array.MySome(even2));
