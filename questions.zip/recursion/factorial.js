
function findFactorial(num) {
    let factorial = 1
    for (let i = num; i > 0; i--) {   
      // factorial = factorial * i
      factorial *= i
    }
    return factorial
  }
  
  const result =findFactorial(5)
  console.log(result) 

  function findFactorial2(num){
    if(num === 0) return 1;
    return num * findFactorial2(num-1)
  }
  const result2 = findFactorial2(4)
  console.log('recursive result', result2)