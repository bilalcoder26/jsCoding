function reverseArray(array){
    let result =[];
    for(let i = array.length-1; i >=0; i--){
        result.push(array[i]);
    }
    return result;

}

const res = reverseArray([9,1,2,0,4,6])

console.log(res)

function reverseArrayWithRecursive(array, left=0, right=array.length-1){
    if(left >= right) return;
    const temp  = array[left];
    array[left] = array[right];
    array[right] = temp
    reverseArrayWithRecursive(array, left + 1, right - 1)

}
const array = [5,12,15,0,3,4]

 reverseArrayWithRecursive(array)
console.log(array)