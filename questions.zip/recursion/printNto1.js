function printNto1(n){
    if(n === 0) return
    console.log('n', n);
    printNto1(n-1);


}

printNto1(5);
//5
//4
//3
//2
//1

function doSomething(n){
if(n===0){
    console.log("Task Completed")
    return 
}
console.log("running task...");
doSomething(n-1);
}

doSomething(3);
