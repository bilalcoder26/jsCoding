function printArrayWithLoop(numArray){
    for(let i = 0; i < numArray.length; i++){
        console.log('printArrayWithLoop',i, numArray[i])
    }

}

printArrayWithLoop([5,6,7,3,21,1]);

function printArrayWithRecursion(numArray, index=0){
    //base case
    if (numArray.length === index) return;
    console.log('printArrayWithRecursion', numArray[index])
    return printArrayWithRecursion(numArray, index + 1);

}
printArrayWithRecursion([9,8,7,5,4]);