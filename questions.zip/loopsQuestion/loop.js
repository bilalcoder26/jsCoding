const data = [
  { name: 'John', age: 30, group: 'A' },
  { name: 'Mary', age: 25, group: 'B' },
  { name: 'Mike', age: 20, group: 'A' },
  { name: 'Jane', age: 15, group: 'C' },
  { name: 'Peter', age: 25, group: 'B' }
];

//forloop
// for(let i=0; i<data.length; i++){
//     console.log(data[i]);
// }

// foreach
// data.forEach(function(data, index){
//     console.log(data, index)
// })

//// for...in loop

// for(const key in data){
//     // console.log(key)
//     console.log(data[key]);
// }

//// for...of loop

// for(const item of data){
//     console.log(item);
// }

//while loop

// let length = data.length, count =0;
// while(length--){
//     console.log(data[count]);
//     console.log('count: ' + count);
//     count++;
// }

// change group of people whose age is greater than 20

// data.forEach(function(data){
//     if(data.age >20){
//         data.group = 'E'
//     }
// })
// console.log(data)

// add isAdult property to each object

// data.forEach(function(data){
//     data.isAdult = data.age > 20;
// })
// console.log(data)

