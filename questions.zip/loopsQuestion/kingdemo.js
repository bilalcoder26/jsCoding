const term  =[
    {
        "masterNomenclatureId": "186d3017-e6d7-4481-afef-a50851572248",
        "tenantTerm": "Traveler",
        "defaultTerm": "Traveler",
        "id": "16f1995f-c8aa-4f61-8f1b-ce2155d51a1d"
    },
    {
        "masterNomenclatureId": "2186c66c-e4a9-49ed-b884-23747d0928bd",
        "tenantTerm": "Self Collect",
        "defaultTerm": "Self Collect",
        "id": "1b2828a8-a2a7-4f07-9daf-aabf2756cadd"
    },
    {
        "masterNomenclatureId": "225df630-bcb8-4f15-9799-d84dada2a45f",
        "tenantTerm": "Product",
        "defaultTerm": "Product",
        "id": "189c6026-5955-44ab-a1ab-f089f7804c87"
    },
    {
        "masterNomenclatureId": "3b719c40-1cc4-4567-aa7e-e7da8052122c",
        "tenantTerm": "Payer",
        "defaultTerm": "Payer",
        "id": "13ec31ae-6f64-4b07-a96c-fab936684a2e"
    },
    {
        "masterNomenclatureId": "474204f6-5809-49be-bcdb-160407ea756c",
        "tenantTerm": "Accomodation",
        "defaultTerm": "Accomodation",
        "id": "8f6bb3d3-7c87-49e3-a398-ad3df0f19846"
    },
    {
        "masterNomenclatureId": "5777cf12-3830-4c20-8cbd-f365d3eab3d2",
        "tenantTerm": "Vendor",
        "defaultTerm": "Vendor",
        "id": "9e46e6c8-bf0a-40e2-b3bd-87cc0a570333"
    },
    {
        "masterNomenclatureId": "5ad33852-54ca-417a-82aa-77cc8c33cebf",
        "tenantTerm": "Number Of Travelers",
        "defaultTerm": "Number Of Travelers",
        "id": "718d9a76-18da-441c-afa7-5baab5a142c5"
    },
    {
        "masterNomenclatureId": "5fb4c7b7-35d1-4947-ae4b-da97b6bdd28a",
        "tenantTerm": "Trip Type",
        "defaultTerm": "Trip Type",
        "id": "05be3583-2dd0-4d58-b129-7ddf5e2b3cc8"
    },
    {
        "masterNomenclatureId": "62e9021c-5344-4383-8a69-45e49360adc2",
        "tenantTerm": "Tracking",
        "defaultTerm": "Tracking",
        "id": "9ead4ce6-860b-41d4-9cfd-6a3f9b41fdad"
    },
    {
        "masterNomenclatureId": "74b44f91-fac3-4290-8fdb-3b782a2cac61",
        "tenantTerm": "Group Collect",
        "defaultTerm": "Group Collect",
        "id": "cb055441-cc22-4832-8f6a-f6ee40be7afe"
    },
    {
        "masterNomenclatureId": "804290ee-eef3-433a-abb1-cc0b7928700c",
        "tenantTerm": "Tour Manager",
        "defaultTerm": "Tour Manager",
        "id": "469ba8ce-5d46-4a42-92d3-828c724da041"
    },
    {
        "masterNomenclatureId": "82f6167e-7405-4e69-9514-31bd825da2b7",
        "tenantTerm": "Commute Type",
        "defaultTerm": "Commute Type",
        "id": "2cd7090e-9e8b-4255-a99e-f4e46e622138"
    },
    {
        "masterNomenclatureId": "8bfd5f66-1451-4f26-809a-8a1f1e2dc217",
        "tenantTerm": "Tenant",
        "defaultTerm": "Tenant",
        "id": "a3140dd0-3057-43f1-b95b-15d8812bf7f4"
    },
    {
        "masterNomenclatureId": "8e965280-201b-4ea2-abdd-67663dd8f3f5",
        "tenantTerm": "Vendor",
        "defaultTerm": "Vendor",
        "id": "18f77772-6845-4234-bd63-14f00d45b712"
    },
    {
        "masterNomenclatureId": "b9c9f829-1436-4e4d-a6a6-3099e7984944",
        "tenantTerm": "Reports",
        "defaultTerm": "Reports",
        "id": "ebb648db-46c9-4c17-bd4b-97f1dbf472c9"
    },
    {
        "masterNomenclatureId": "c3b7d2a0-4da8-4c03-9406-5b02f9ccbc20",
        "tenantTerm": "Cost Sheet",
        "defaultTerm": "Cost Sheet",
        "id": "314d8524-a40b-4052-b919-0aac5dde8e0c"
    },
    {
        "masterNomenclatureId": "c4640405-9724-4a13-8c1d-5b9ea2ca1433",
        "tenantTerm": "Tour Coordinator",
        "defaultTerm": "Tour Coordinator",
        "id": "5205323e-e84e-4695-9187-cef36e6a2c40"
    },
    {
        "masterNomenclatureId": "c9a7ad5d-b151-484a-a3ed-c39cb5184fbe",
        "tenantTerm": "Tour",
        "defaultTerm": "Tour",
        "id": "cc3c5cda-1eb3-457d-bb0f-2bd8565a5644"
    },
    {
        "masterNomenclatureId": "ccf5d52d-330e-4420-ad87-9521fac1cd00",
        "tenantTerm": "Trip Cost",
        "defaultTerm": "Trip Cost",
        "id": "10a9fff0-e1eb-452f-b5e9-9e6feaf1a709"
    },
    {
        "masterNomenclatureId": "d3ef121f-a446-44ab-ac51-504b4f4437b1",
        "tenantTerm": "Destination",
        "defaultTerm": "Destination",
        "id": "d73bc749-6cb9-45bb-8548-53ddf7fa9065"
    },
    {
        "masterNomenclatureId": "deff40d0-799a-438f-b099-b982b7dc8ae9",
        "tenantTerm": "Collection Type",
        "defaultTerm": "Collection Type",
        "id": "88785e61-c0c5-432e-84f9-eb9e12797265"
    },
    {
        "masterNomenclatureId": "f01c48c6-50d4-46a9-b618-fa9b389fe39d",
        "tenantTerm": "Account Type",
        "defaultTerm": "Account Type",
        "id": "f7163582-de98-460b-9005-035d3cebfbcc"
    },
    {
        "masterNomenclatureId": "fcec6a48-1d0d-4d08-ad10-5f6a25b6478f",
        "tenantTerm": "Fund Raising",
        "defaultTerm": "Fund Raising",
        "id": "e660666a-6d9c-4614-b663-e513ea9994ac"
    },
    {
        "masterNomenclatureId": "040ca264-912b-4704-b44b-b90df75959e8",
        "tenantTerm": "Cruise",
        "defaultTerm": "Cruise",
        "id": "0bec42f6-a093-4d64-b722-1c9310e006ab"
    },
    {
        "masterNomenclatureId": "09af2909-fa92-40fe-8660-d592e090652b",
        "tenantTerm": "Infant",
        "defaultTerm": "Infant",
        "id": "74c2f145-3fd1-419e-a441-4717d5c3af32"
    },
    {
        "masterNomenclatureId": "0c03845d-a02d-4e98-9f3c-9dafef6a1d2b",
        "tenantTerm": "Mr",
        "defaultTerm": "Mr",
        "id": "683c8df0-11eb-4298-b4ff-e01948bd4ca7"
    },
    {
        "masterNomenclatureId": "0f757619-918d-4bf1-a51d-c8caa6f3de3a",
        "tenantTerm": "Fundraising",
        "defaultTerm": "Fundraising",
        "id": "7feca017-b29b-4e8c-a2eb-468f5ec02eb7"
    },
    {
        "masterNomenclatureId": "101d9f67-97e9-44ba-ade0-396c9a315b15",
        "tenantTerm": "Over Night",
        "defaultTerm": "Over Night",
        "id": "44ddf348-1c80-495a-9170-02ed3a6e59da"
    },
    {
        "masterNomenclatureId": "15df35ff-f5a9-49fe-8441-ef27333ded53",
        "tenantTerm": "Debit Card",
        "defaultTerm": "Debit Card",
        "id": "ae1e8633-a056-4ae4-97e7-c307f9481a0b"
    },
    {
        "masterNomenclatureId": "15f022c6-525c-481a-9168-0e9cf263cd15",
        "tenantTerm": "Cheque",
        "defaultTerm": "Cheque",
        "id": "1e31076e-dc59-4a57-baaf-60643c1cfbd7"
    },
    {
        "masterNomenclatureId": "192d2f54-8cdd-4e44-ad39-b228b985d4bc",
        "tenantTerm": "Hotel",
        "defaultTerm": "Hotel",
        "id": "febe576f-3da9-4526-9ab7-a92190d41121"
    },
    {
        "masterNomenclatureId": "2032c616-bcd3-45a2-8683-0eb92d695ad7",
        "tenantTerm": "Fixed",
        "defaultTerm": "Fixed",
        "id": "ae8ad2cb-a112-4239-b299-a0b9027b3509"
    },
    {
        "masterNomenclatureId": "2478714e-d2a0-4804-acf5-56f32aa5eea2",
        "tenantTerm": "Quote",
        "defaultTerm": "Quote",
        "id": "4c16c1ca-0359-469a-8f45-0c1d52529dba"
    },
    {
        "masterNomenclatureId": "2666772b-329b-42d3-bc8e-a419bdba162d",
        "tenantTerm": "Cheque",
        "defaultTerm": "Cheque",
        "id": "90c575d7-b7ec-4774-8936-b9916fe34af1"
    },
    {
        "masterNomenclatureId": "2dec2238-b706-4fb9-8c4d-61c603d09c6b",
        "tenantTerm": "Active",
        "defaultTerm": "Active",
        "id": "12682aff-2a57-47b2-9b12-2f3b278ce17b"
    },
    {
        "masterNomenclatureId": "3387c09c-b5e3-4d12-bfb3-91bf53884f8e",
        "tenantTerm": "Attraction",
        "defaultTerm": "Attraction",
        "id": "deecc66c-c326-4163-873b-51cca34c569e"
    },
    {
        "masterNomenclatureId": "34513243-39cc-47e0-aad3-bb8f62077d61",
        "tenantTerm": "Lump-Sum",
        "defaultTerm": "Lump-Sum",
        "id": "c166b75e-b3b7-4f79-a451-c4c52c0e36a8"
    },
    {
        "masterNomenclatureId": "3599ab29-2033-4e2d-869c-b96679c83f66",
        "tenantTerm": "Service Provider",
        "defaultTerm": "Service Provider",
        "id": "8cd2209a-524b-464b-b696-1564b1c646a8"
    },
    {
        "masterNomenclatureId": "39d2c3dd-fa88-4983-988b-b5f1acab2a49",
        "tenantTerm": "Credit On File",
        "defaultTerm": "Credit On File",
        "id": "66007e1e-7666-4909-a20a-b4eac5f55eec"
    },
    {
        "masterNomenclatureId": "3d11ffeb-9668-45c0-b63e-05dd55be23c4",
        "tenantTerm": "Variables",
        "defaultTerm": "Variables",
        "id": "3f117a2e-7013-4971-bf48-21ee7c36b8d6"
    },
    {
        "masterNomenclatureId": "45aa00d8-07cb-4082-914f-6f90d2c46941",
        "tenantTerm": "Bus",
        "defaultTerm": "Bus",
        "id": "f0a1bb54-fb2c-4e43-8bc1-4010fb82ddf3"
    },
    {
        "masterNomenclatureId": "47c94b60-4b2b-4ebf-af7c-8c258d3d0158",
        "tenantTerm": "Partial Paid",
        "defaultTerm": "Partial Paid",
        "id": "d5a0c3e4-9431-474a-9cd4-46a905dd1745"
    },
    {
        "masterNomenclatureId": "4ecb2cb7-7242-46f5-9bbc-72441a574b3a",
        "tenantTerm": "Credit Card",
        "defaultTerm": "Credit Card",
        "id": "200ca26b-e5ab-4425-bf57-a9d2359a8bfa"
    },
    {
        "masterNomenclatureId": "4f0a8db6-f8e8-4016-91d2-b05c7c8d82ee",
        "tenantTerm": "Scholarship",
        "defaultTerm": "Scholarship",
        "id": "2569f8bd-64ef-4390-95b4-cd88c5aabfed"
    },
    {
        "masterNomenclatureId": "5138abf1-98b9-4923-8705-b8a8ddd02fb8",
        "tenantTerm": "Cancelled",
        "defaultTerm": "Cancelled",
        "id": "e79185c8-5405-4e1d-a4ed-dd242aae6e01"
    },
    {
        "masterNomenclatureId": "5359fb64-f2d8-4823-a66f-a1062e31d3a0",
        "tenantTerm": "Closed",
        "defaultTerm": "Closed",
        "id": "d0817ade-6cc7-47b4-85ac-97c0e0c1d031"
    },
    {
        "masterNomenclatureId": "549acfe4-5ede-4696-b17e-598dfa7a517d",
        "tenantTerm": "Pre Payment",
        "defaultTerm": "Pre Payment",
        "id": "92a85ed0-ef00-4693-97e8-6180cb82c7b8"
    },
    {
        "masterNomenclatureId": "58e00f53-0b38-4a6a-88dd-99d770877fed",
        "tenantTerm": "Corporate",
        "defaultTerm": "Corporate",
        "id": "edfb01f3-6e9b-4cdb-a5de-b79b3bf14eb0"
    },
    {
        "masterNomenclatureId": "5c17e947-813c-48e4-b0c5-ae59043310eb",
        "tenantTerm": "Confirmed",
        "defaultTerm": "Confirmed",
        "id": "b02e20d1-d259-4e48-a76d-c59f4763c965"
    },
    {
        "masterNomenclatureId": "65d8def4-df9e-4a57-aec2-14d1c0c7d71d",
        "tenantTerm": "Debit Card",
        "defaultTerm": "Debit Card",
        "id": "fa899bdb-40a5-41b9-9a1c-2ebc187df314"
    },
    {
        "masterNomenclatureId": "6604b928-124c-472f-bf09-63daad2f4b13",
        "tenantTerm": "Not Paid",
        "defaultTerm": "Not Paid",
        "id": "30d5f3e0-43d5-4284-b329-5aa87b674a23"
    },
    {
        "masterNomenclatureId": "7564b43a-5119-46c5-bf0b-bf47ed1343bf",
        "tenantTerm": "CVB",
        "defaultTerm": "CVB",
        "id": "fa3a9f08-7ee1-4cce-bef1-8035c01903bc"
    },
    {
        "masterNomenclatureId": "79ec131e-c5f3-4669-93a0-f07495d540ce",
        "tenantTerm": "Day",
        "defaultTerm": "Day",
        "id": "fd22df76-d196-4264-8f7b-5069958ad37c"
    },
    {
        "masterNomenclatureId": "842cfd9b-65dc-4bc8-9a58-9e8e44f8e79c",
        "tenantTerm": "Individual",
        "defaultTerm": "Individual",
        "id": "e41eca68-f9fb-4d7e-8990-e04ca8a1bd7b"
    },
    {
        "masterNomenclatureId": "85e3343c-dfb6-45ff-94cb-abde7e9f843c",
        "tenantTerm": "Other",
        "defaultTerm": "Other",
        "id": "b21f12c6-5ee4-478f-870f-378670f74624"
    },
    {
        "masterNomenclatureId": "8e0a043a-324c-464d-82d2-f995a3cbe252",
        "tenantTerm": "Restaurant",
        "defaultTerm": "Restaurant",
        "id": "16fae870-a68f-4504-a90e-1fe18efef027"
    },
    {
        "masterNomenclatureId": "91880383-b3fd-44c6-9412-30a94bcc4c01",
        "tenantTerm": "Professor",
        "defaultTerm": "Professor",
        "id": "e2f16365-4586-4c51-937b-396d97ca90f4"
    },
    {
        "masterNomenclatureId": "92c79f15-5511-4eca-a5c7-93c4e583088e",
        "tenantTerm": "Cash",
        "defaultTerm": "Cash",
        "id": "e4b2adbb-ac47-44cb-a82c-6e3bd22737fc"
    },
    {
        "masterNomenclatureId": "a8bac02e-4569-49ca-9db0-44fba88d1bf0",
        "tenantTerm": "Master",
        "defaultTerm": "Master",
        "id": "63680d9d-8c3a-42f6-b0b6-c1531425fa55"
    },
    {
        "masterNomenclatureId": "aae54a60-26c2-4be9-9844-bebd37598cf5",
        "tenantTerm": "Invoiced Post Tour",
        "defaultTerm": "Invoiced Post Tour",
        "id": "95f903ce-4a5e-4085-85d9-ce27aed7013c"
    },
    {
        "masterNomenclatureId": "b4f32ed0-d7d8-4f6c-97ab-548ea989d7da",
        "tenantTerm": "Paid",
        "defaultTerm": "Paid",
        "id": "9c1bb963-4e99-403f-ac10-e3adb99c8174"
    },
    {
        "masterNomenclatureId": "bcb591b2-c573-435d-9ec3-f98907b00a02",
        "tenantTerm": "Adult",
        "defaultTerm": "Adult",
        "id": "87540c69-39e6-4792-9122-762ba0283be3"
    },
    {
        "masterNomenclatureId": "c65130e5-39bb-4c91-b042-435af37f84d2",
        "tenantTerm": "Tentative",
        "defaultTerm": "Tentative",
        "id": "92286cd8-33a8-431a-beef-65d52c624777"
    },
    {
        "masterNomenclatureId": "ccd06948-e342-44e3-b7b5-66e304458ac0",
        "tenantTerm": "Cash",
        "defaultTerm": "Cash",
        "id": "a6d9644e-1e74-4078-85de-e2af84b68208"
    },
    {
        "masterNomenclatureId": "d9f31eb1-fc91-42ed-bece-a3eaca3d5c0d",
        "tenantTerm": "Credit Card",
        "defaultTerm": "Credit Card",
        "id": "539b15b1-b8f2-4178-9fa3-6846c4b205e1"
    },
    {
        "masterNomenclatureId": "e0dc2386-30a6-4d04-bc5f-eb1a374c595b",
        "tenantTerm": "Mrs",
        "defaultTerm": "Mrs",
        "id": "146438f1-9f12-417c-a2ff-744ec8ca2c5f"
    },
    {
        "masterNomenclatureId": "e60bb21d-cca3-44ec-b302-da5f84cd3375",
        "tenantTerm": "Bus",
        "defaultTerm": "Bus",
        "id": "45fe8ed8-8188-461f-b1a2-23b576400642"
    },
    {
        "masterNomenclatureId": "eb03e9ea-0d9e-47dd-9b72-9612d3c1c9e6",
        "tenantTerm": "Airline",
        "defaultTerm": "Airline",
        "id": "8c8c6d02-575f-446d-ac43-972c4bef09e8"
    },
    {
        "masterNomenclatureId": "f20367d8-fa93-4379-8f54-25b934948b91",
        "tenantTerm": "Miss",
        "defaultTerm": "Miss",
        "id": "6e3e96e4-5954-45e8-8456-d62781055a5d"
    },
    {
        "masterNomenclatureId": "f2d75db3-7a2c-45bd-9fe8-d4e129a19c89",
        "tenantTerm": "Doctor",
        "defaultTerm": "Doctor",
        "id": "8d202edc-8fee-4407-9df8-ee8a0d470690"
    },
    {
        "masterNomenclatureId": "f4c59a5f-e8a7-4597-ba80-da3116d79af7",
        "tenantTerm": "Child",
        "defaultTerm": "Child",
        "id": "a6fba5f7-ba0f-48ee-9287-5913aeec617b"
    },
    {
        "masterNomenclatureId": "00b7d960-e7ce-43de-8caf-1c57d8e6d370",
        "tenantTerm": "Child",
        "defaultTerm": "Child",
        "id": "4e1cf9d6-4279-4395-b8de-b85dcbaba563"
    },
    {
        "masterNomenclatureId": "018b6eae-02f9-4b8f-84d0-56c7a1e3e356",
        "tenantTerm": "Bus",
        "defaultTerm": "Bus",
        "id": "08cdbe7f-1421-430d-af43-c1c1bed5fa54"
    },
    {
        "masterNomenclatureId": "01ffe871-06d9-4629-949b-9268228d0d64",
        "tenantTerm": "Infant",
        "defaultTerm": "Infant",
        "id": "5495f7cd-0d75-4184-b88d-faea3c71cddc"
    },
    {
        "masterNomenclatureId": "101359a1-5651-4a83-8327-d53bff1b1007",
        "tenantTerm": "Lump-Sum",
        "defaultTerm": "Lump-Sum",
        "id": "6826f1ae-35c4-48be-b621-40d03a808d16"
    },
    {
        "masterNomenclatureId": "14702527-5d9e-4c70-87f1-1b939601ad20",
        "tenantTerm": "Cash",
        "defaultTerm": "Cash",
        "id": "81f657e8-fef1-43cf-83e3-e95c0dabefd2"
    },
    {
        "masterNomenclatureId": "166abe71-e165-4481-96f1-8eef2ac1e899",
        "tenantTerm": "Pre Payment",
        "defaultTerm": "Pre Payment",
        "id": "a79a64eb-7816-45ae-9c97-4920177f881a"
    },
    {
        "masterNomenclatureId": "1a3c9495-8078-4cab-a24b-5a84f4471a60",
        "tenantTerm": "Not Paid",
        "defaultTerm": "Not Paid",
        "id": "2a0ae190-1c3a-4925-816a-f4f1d210303b"
    },
    {
        "masterNomenclatureId": "2156f412-192f-4857-b0d0-227afd33236b",
        "tenantTerm": "Scholarship",
        "defaultTerm": "Scholarship",
        "id": "9b7c71a3-19cc-4fb4-8723-92cf1e537c5d"
    },
    {
        "masterNomenclatureId": "28e89a59-a6fe-436f-87d7-d96c9f352dae",
        "tenantTerm": "Confirmed",
        "defaultTerm": "Confirmed",
        "id": "b00b5425-d062-4738-9087-50b26547b503"
    },
    {
        "masterNomenclatureId": "292edf16-47c7-42b0-b529-e1edaf5080e2",
        "tenantTerm": "Credit Card",
        "defaultTerm": "Credit Card",
        "id": "911c0238-3a31-4257-9078-e0530f650906"
    },
    {
        "masterNomenclatureId": "2a61d3cb-5971-4135-a2c2-64e6c9ed1492",
        "tenantTerm": "Cheque",
        "defaultTerm": "Cheque",
        "id": "3108c02c-a639-4529-98c7-949bd8c870ed"
    },
    {
        "masterNomenclatureId": "2c7a681d-2f4c-4416-b7c8-b9a81efe9d34",
        "tenantTerm": "Invoiced Post Trip",
        "defaultTerm": "Invoiced Post Trip",
        "id": "811bdae4-6ee8-4f73-839f-bf0ac2fb2b0b"
    },
    {
        "masterNomenclatureId": "353d5a5d-c05e-4cb4-abdc-6af645b94834",
        "tenantTerm": "Debit Card",
        "defaultTerm": "Debit Card",
        "id": "119a9027-f435-445f-a0ea-0a17419e9a1d"
    },
    {
        "masterNomenclatureId": "38edba87-1a0f-4514-964b-1a39d7eee4db",
        "tenantTerm": "Over Night",
        "defaultTerm": "Over Night",
        "id": "9a1902d5-a789-412c-b295-d03ee16305d0"
    },
    {
        "masterNomenclatureId": "39969980-d6dd-4014-bb14-a84f1a33cc54",
        "tenantTerm": "Cheque",
        "defaultTerm": "Cheque",
        "id": "07fc1c3b-9a42-4e48-8b80-a7068f3b010a"
    },
    {
        "masterNomenclatureId": "3e476060-32db-4990-ab2c-66df22b8cf08",
        "tenantTerm": "Quote",
        "defaultTerm": "Quote",
        "id": "7ee386fb-39c5-4353-bd1f-5ac384a07e83"
    },
    {
        "masterNomenclatureId": "3f14f777-f9b5-428c-be34-569a1009df8f",
        "tenantTerm": "Airline",
        "defaultTerm": "Airline",
        "id": "363449fd-4a39-4edd-85c5-fdf295cc8b80"
    },
    {
        "masterNomenclatureId": "3fb1cdb4-dc50-46ae-9c81-9854be579af9",
        "tenantTerm": "Fundraising",
        "defaultTerm": "Fundraising",
        "id": "4cca18e7-5a82-4081-9631-6320846a406e"
    },
    {
        "masterNomenclatureId": "447a8621-e387-4c62-bae7-379fb07148f3",
        "tenantTerm": "CVB",
        "defaultTerm": "CVB",
        "id": "2a12a232-756d-4293-9efd-4f428f17f12d"
    },
    {
        "masterNomenclatureId": "4fe64609-0520-4754-9f7e-70afd1f5d807",
        "tenantTerm": "Fixed",
        "defaultTerm": "Fixed",
        "id": "f505b34c-6c36-43c1-a471-b1f7cd44080a"
    },
    {
        "masterNomenclatureId": "5adc2d47-4875-4ffe-9025-94c4ac70c9a9",
        "tenantTerm": "Other",
        "defaultTerm": "Other",
        "id": "412821ae-b400-4ba4-8783-31a9ce0b8b8a"
    },
    {
        "masterNomenclatureId": "61d995bf-cb3c-438e-8bc7-7137fca63801",
        "tenantTerm": "Day",
        "defaultTerm": "Day",
        "id": "4b2786b1-e131-47f8-8a2c-4e1550020a71"
    },
    {
        "masterNomenclatureId": "643fa554-59c6-409c-b368-ace28130b339",
        "tenantTerm": "Closed",
        "defaultTerm": "Closed",
        "id": "18a87b9b-7cca-44c5-aaf7-cdff7469691f"
    },
    {
        "masterNomenclatureId": "6587c9c0-54ce-4765-ad7a-bec049a5f8c0",
        "tenantTerm": "Credit Card",
        "defaultTerm": "Credit Card",
        "id": "58f95163-ff0a-4e05-96da-ba063eaca2b6"
    },
    {
        "masterNomenclatureId": "748d7a93-f6a8-4003-908c-f30a078adcd9",
        "tenantTerm": "Hotel",
        "defaultTerm": "Hotel",
        "id": "9617edcb-b442-4920-bad5-e1880be62bfb"
    },
    {
        "masterNomenclatureId": "7ec198b0-072e-4db7-94c3-02c6832a4d4a",
        "tenantTerm": "Credit On File",
        "defaultTerm": "Credit On File",
        "id": "f471e266-76f2-419d-95ae-408aa7525553"
    },
    {
        "masterNomenclatureId": "7ec7d7c1-53b7-436a-b43b-a3df39fc5386",
        "tenantTerm": "Miss",
        "defaultTerm": "Miss",
        "id": "b5c53825-e8da-47aa-b06d-758bab140ee7"
    },
    {
        "masterNomenclatureId": "7fa542a4-85ae-4c90-913c-495887516388",
        "tenantTerm": "Cash",
        "defaultTerm": "Cash",
        "id": "f5219206-eb31-4ab8-9810-2cf193d20139"
    },
    {
        "masterNomenclatureId": "8558c816-c2c7-4b64-ad8a-294da180f636",
        "tenantTerm": "Doctor",
        "defaultTerm": "Doctor",
        "id": "c4ea9a6d-4b25-4d44-b74d-532029ddb4e7"
    },
    {
        "masterNomenclatureId": "8b2190f9-4730-47cb-82c7-aea1e4f2dbd1",
        "tenantTerm": "Adult",
        "defaultTerm": "Adult",
        "id": "7281c354-ebe0-4297-8063-685ba985cebe"
    },
    {
        "masterNomenclatureId": "8bc480dc-b69e-4956-bb4a-1de9e63bae92",
        "tenantTerm": "Active",
        "defaultTerm": "Active",
        "id": "a82ac6f1-a07c-4607-bab7-1c6223e6dd08"
    },
    {
        "masterNomenclatureId": "8e6a7547-27e7-4c0a-ad9d-f82899569e16",
        "tenantTerm": "Tentative",
        "defaultTerm": "Tentative",
        "id": "a6cda294-af56-4d59-9453-03828c38b1f6"
    },
    {
        "masterNomenclatureId": "91852a54-91d2-43d2-b8a7-36e7ccdce922",
        "tenantTerm": "Professor",
        "defaultTerm": "Professor",
        "id": "a28883bc-ed23-4296-ac13-96a58de78ea9"
    },
    {
        "masterNomenclatureId": "96ff2fbf-340a-47a3-a650-40c2588d6e27",
        "tenantTerm": "Variables",
        "defaultTerm": "Variables",
        "id": "ffbbf649-c2ae-48fa-907c-ccc0e20b0f5e"
    },
    {
        "masterNomenclatureId": "98b5e23c-29d7-4dfb-b40f-f9a64bd2cb37",
        "tenantTerm": "Individual",
        "defaultTerm": "Individual",
        "id": "99b6414d-d81a-4c0c-8fbc-c7c716b82216"
    },
    {
        "masterNomenclatureId": "9f49cd4f-930a-4c73-aff7-18b293f75a3f",
        "tenantTerm": "Bus",
        "defaultTerm": "Bus",
        "id": "54684de6-428c-45a5-8260-2fbd8cce3fed"
    },
    {
        "masterNomenclatureId": "a1c6357b-a633-44d9-b2ce-f8f5cec44ac1",
        "tenantTerm": "Mr",
        "defaultTerm": "Mr",
        "id": "09229c79-26c3-4ab4-8e1f-95197525281f"
    },
    {
        "masterNomenclatureId": "a3b88060-61c8-4322-bc5b-7a835b3220ef",
        "tenantTerm": "Mrs",
        "defaultTerm": "Mrs",
        "id": "184c6e4d-7827-45b8-ab93-0c27c5752779"
    },
    {
        "masterNomenclatureId": "a41fe626-80d1-4164-9ded-8b5416e38723",
        "tenantTerm": "Corporate",
        "defaultTerm": "Corporate",
        "id": "209a0804-2cb4-4b83-ae68-c2a8579ae279"
    },
    {
        "masterNomenclatureId": "ae715cd3-7d49-4d2d-b61f-bc5b92e25ba1",
        "tenantTerm": "Debit Card",
        "defaultTerm": "Debit Card",
        "id": "8ca54087-0977-4316-aaa6-816026db5d31"
    },
    {
        "masterNomenclatureId": "ba9ba528-9821-4bdc-87f8-94e8a04e3a96",
        "tenantTerm": "Paid",
        "defaultTerm": "Paid",
        "id": "1744864f-5538-4434-b3a5-5596e8b02256"
    },
    {
        "masterNomenclatureId": "babeb958-83dd-462e-97ce-de654d3563da",
        "tenantTerm": "Attraction",
        "defaultTerm": "Attraction",
        "id": "48781438-c440-4ebd-92f0-7a55ceb39971"
    },
    {
        "masterNomenclatureId": "c7622aea-070e-4fbd-8b11-2429f5bf0b56",
        "tenantTerm": "Master",
        "defaultTerm": "Master",
        "id": "77159ef1-bc63-4a21-8892-447633ae57f0"
    },
    {
        "masterNomenclatureId": "c95ecbc2-44de-47f0-a006-463803e51afb",
        "tenantTerm": "Restaurant",
        "defaultTerm": "Restaurant",
        "id": "a16129b3-9b1a-4806-a426-d8c3a40576f7"
    },
    {
        "masterNomenclatureId": "d911ebb0-16e0-42c6-9938-d41c8b7c9208",
        "tenantTerm": "Partial Paid",
        "defaultTerm": "Partial Paid",
        "id": "14b9be1c-ab5c-49fc-a737-25d714c39abf"
    },
    {
        "masterNomenclatureId": "e550d34a-189a-4f44-9c7a-35617a0d0b5b",
        "tenantTerm": "Cancelled",
        "defaultTerm": "Cancelled",
        "id": "fa34f2f4-c8ed-4152-af73-21ca62e2a5f8"
    },
    {
        "masterNomenclatureId": "f5c28ecf-e03e-4d67-a1f9-e4793e29a5cb",
        "tenantTerm": "Cruise",
        "defaultTerm": "Cruise",
        "id": "982a4546-708e-4e15-adaf-57946e62f905"
    },
    {
        "masterNomenclatureId": "fbe7164d-f807-43d9-99e9-f417b155afc3",
        "tenantTerm": "Service Provider",
        "defaultTerm": "Service Provider",
        "id": "9a49c81a-9235-4efc-b583-16baa5fec7f4"
    },
    {
        "masterNomenclatureId": "01b0a0b8-bbec-484a-ac42-cf1f936f435b",
        "tenantTerm": "CVB",
        "defaultTerm": "CVB",
        "id": "5abed13b-bd75-4bdc-93c3-3b170cd5f771"
    },
    {
        "masterNomenclatureId": "092feae2-69da-4c3a-8d63-3c765630479d",
        "tenantTerm": "Cash",
        "defaultTerm": "Cash",
        "id": "8c90907f-7d5e-4e9a-9a83-1606ee70d0fd"
    },
    {
        "masterNomenclatureId": "18141942-5ad8-42be-bffe-3c2e8e34042a",
        "tenantTerm": "Professor",
        "defaultTerm": "Professor",
        "id": "1fe98779-1703-4834-9bee-490d0893ea9e"
    },
    {
        "masterNomenclatureId": "1c6d2d36-6a26-4a4b-84cd-b85de96744ad",
        "tenantTerm": "Individual",
        "defaultTerm": "Individual",
        "id": "822d22e8-9632-41b1-9b2d-a840de213e4b"
    },
    {
        "masterNomenclatureId": "27d1620a-3476-496c-b4fc-a323637d8a38",
        "tenantTerm": "Airline",
        "defaultTerm": "Airline",
        "id": "95d94797-69b8-4897-a5e6-17415ea268bc"
    },
    {
        "masterNomenclatureId": "31c2eef9-1c11-4d48-9e2c-1315827d758f",
        "tenantTerm": "Other",
        "defaultTerm": "Other",
        "id": "05734ee2-a076-48c3-9eed-4b0d19847494"
    },
    {
        "masterNomenclatureId": "371c0d02-5266-4b46-b363-3bd8e9f7595f",
        "tenantTerm": "Mr",
        "defaultTerm": "Mr",
        "id": "78e0c654-5832-4d88-acc6-1381b3d13219"
    },
    {
        "masterNomenclatureId": "39cdf7e6-d78e-4e3e-b4ed-26a4439b4f22",
        "tenantTerm": "Partial Paid",
        "defaultTerm": "Partial Paid",
        "id": "91495907-af76-4460-8f00-bd886a19f980"
    },
    {
        "masterNomenclatureId": "472f5ed2-a9c9-47b4-8f95-230e3c45e2a0",
        "tenantTerm": "Service Provider",
        "defaultTerm": "Service Provider",
        "id": "c8a874b8-84d9-4a62-b494-d9226fe9f55e"
    },
    {
        "masterNomenclatureId": "47d78ee3-1ea5-4197-a6b4-4a53c25e3ba0",
        "tenantTerm": "Credit On File",
        "defaultTerm": "Credit On File",
        "id": "eef52881-fc06-4166-aa46-4b4f73f699d6"
    },
    {
        "masterNomenclatureId": "4e13a9e0-3933-4b6d-ac16-a94b210bdd96",
        "tenantTerm": "Not Paid",
        "defaultTerm": "Not Paid",
        "id": "8f34c777-3872-4dd9-bcb5-c7b3fe2bd0b8"
    },
    {
        "masterNomenclatureId": "51748f0b-341a-4121-856c-870d25c5a3b8",
        "tenantTerm": "Pre Payment",
        "defaultTerm": "Pre Payment",
        "id": "524d3326-4d5a-44fc-a660-73e53b83c0ad"
    },
    {
        "masterNomenclatureId": "60171110-0d16-4afa-819d-36654a5678b3",
        "tenantTerm": "Cruise",
        "defaultTerm": "Cruise",
        "id": "64136c80-638d-407c-8fde-988c847fd1b3"
    },
    {
        "masterNomenclatureId": "6213f1b3-11cc-4ef7-a7de-ac23d5ce75e9",
        "tenantTerm": "Doctor",
        "defaultTerm": "Doctor",
        "id": "3b544528-011f-400f-91b9-90d4dcd00801"
    },
    {
        "masterNomenclatureId": "640bed48-0ac8-48fc-b048-0564a7c82169",
        "tenantTerm": "Adult",
        "defaultTerm": "Adult",
        "id": "573dcfa2-8b69-45ab-862b-fbfb4c7faef6"
    },
    {
        "masterNomenclatureId": "651587f2-2498-4029-b7a1-3eba631d638f",
        "tenantTerm": "Bus",
        "defaultTerm": "Bus",
        "id": "86ac38d7-1a72-4b16-99da-569499f6a51f"
    },
    {
        "masterNomenclatureId": "6a000416-48a0-43e2-8acd-3031f732a22a",
        "tenantTerm": "Master",
        "defaultTerm": "Master",
        "id": "23f2170c-0c34-4407-a3d7-8cea5852ba08"
    },
    {
        "masterNomenclatureId": "6deaf6a5-d9bb-4bfd-a836-dd4792104e25",
        "tenantTerm": "Infant",
        "defaultTerm": "Infant",
        "id": "187619cf-093a-416d-b74b-9022f0fdc00b"
    },
    {
        "masterNomenclatureId": "70c24721-167b-4965-a893-2666c4110c05",
        "tenantTerm": "Cheque",
        "defaultTerm": "Cheque",
        "id": "8ae6020b-925e-4ccd-ad62-4cb498aef41e"
    },
    {
        "masterNomenclatureId": "72483b28-a108-4117-be36-a3a1ccb64155",
        "tenantTerm": "Child",
        "defaultTerm": "Child",
        "id": "3a8917b9-6509-4316-abff-c86fda7c478b"
    },
    {
        "masterNomenclatureId": "7399a51b-49fd-4d8d-888c-715e65b8bf9a",
        "tenantTerm": "Confirmed",
        "defaultTerm": "Confirmed",
        "id": "f913c82d-0616-4f43-b107-934da120ed95"
    },
    {
        "masterNomenclatureId": "7486446e-7580-4229-a042-20508a00d35f",
        "tenantTerm": "Over Night",
        "defaultTerm": "Over Night",
        "id": "aacb50cc-e38a-4916-8a43-7b3100eec051"
    },
    {
        "masterNomenclatureId": "74b45737-4f5d-4424-a3e7-63a34b892d87",
        "tenantTerm": "Hotel",
        "defaultTerm": "Hotel",
        "id": "63824779-ab1d-4f07-899a-f3d6a79734f2"
    },
    {
        "masterNomenclatureId": "7f94c84d-584c-4dc7-87c1-a77876abb8c3",
        "tenantTerm": "Credit Card",
        "defaultTerm": "Credit Card",
        "id": "1a2044e1-53e4-4303-bc3d-c7095317c61a"
    },
    {
        "masterNomenclatureId": "815f7687-7755-4304-8f50-082a8a45c05a",
        "tenantTerm": "Variables",
        "defaultTerm": "Variables",
        "id": "2f8643ad-7d48-4bc6-9b19-2190888ff794"
    },
    {
        "masterNomenclatureId": "8dd89646-fe1e-4cd4-b695-31402c679344",
        "tenantTerm": "Closed",
        "defaultTerm": "Closed",
        "id": "00990dd3-8182-404f-bbcb-e49a1a2575f0"
    },
    {
        "masterNomenclatureId": "8eceeec1-94ff-4bb7-978d-d9b52008ca8b",
        "tenantTerm": "Restaurant",
        "defaultTerm": "Restaurant",
        "id": "2072caee-2521-4612-b0e0-2bc06cba8c6b"
    },
    {
        "masterNomenclatureId": "970e8d3c-174a-4c81-a236-e1af2b8b50b9",
        "tenantTerm": "Cash",
        "defaultTerm": "Cash",
        "id": "39579617-a47f-476b-b6f8-5f15132eb415"
    },
    {
        "masterNomenclatureId": "9c178a9f-267c-413b-874b-1987d98c9880",
        "tenantTerm": "Fundraising",
        "defaultTerm": "Fundraising",
        "id": "ddedf28a-a549-4c84-b4f3-940c12ec8a46"
    },
    {
        "masterNomenclatureId": "ad398a0a-4c2d-463d-b3e3-d54a50a6c13a",
        "tenantTerm": "Attraction",
        "defaultTerm": "Attraction",
        "id": "863ffc2c-b599-4a84-9259-d5e28dc2bcaa"
    },
    {
        "masterNomenclatureId": "af57eda8-99df-4ab7-bd5f-b49f74401de7",
        "tenantTerm": "Cheque",
        "defaultTerm": "Cheque",
        "id": "d2ac68e8-8801-452c-b3d5-6ff77a96d3fb"
    },
    {
        "masterNomenclatureId": "b725b384-2c3e-4532-b394-05aa4685d1a8",
        "tenantTerm": "Quote",
        "defaultTerm": "Quote",
        "id": "72ada9f9-f79d-406b-9855-b77b40d04467"
    },
    {
        "masterNomenclatureId": "bf205967-d0a2-423a-8cbf-68ed092aa313",
        "tenantTerm": "Cancelled",
        "defaultTerm": "Cancelled",
        "id": "bd344623-c2dd-4356-b7c3-7f11eec44ab9"
    },
    {
        "masterNomenclatureId": "c18ba510-040a-494b-9c3a-aa0a86a9cdc5",
        "tenantTerm": "Miss",
        "defaultTerm": "Miss",
        "id": "347fe6e3-a419-473b-b868-72ddd62e6a97"
    },
    {
        "masterNomenclatureId": "c316ad36-8ea4-474a-8653-4649db155005",
        "tenantTerm": "Active",
        "defaultTerm": "Active",
        "id": "f5cd2bb1-e766-4fd0-9a69-a179aff17339"
    },
    {
        "masterNomenclatureId": "c4d5c195-bb91-4b50-83bf-969cf7fa50da",
        "tenantTerm": "Scholarship",
        "defaultTerm": "Scholarship",
        "id": "bdb72d1c-ca5e-40f4-af50-8ec7fac25711"
    },
    {
        "masterNomenclatureId": "ca96a793-4eb0-46cd-b137-47f10fb35f80",
        "tenantTerm": "Tentative",
        "defaultTerm": "Tentative",
        "id": "948d2ce7-12cd-4f5c-8001-c6afad61f8ba"
    },
    {
        "masterNomenclatureId": "cb318ca1-d133-4b58-912d-639a76211dca",
        "tenantTerm": "Paid",
        "defaultTerm": "Paid",
        "id": "2a36e185-7af8-4614-bf19-f865f3edf3a2"
    },
    {
        "masterNomenclatureId": "cb65a312-6c5a-47ee-b35c-adb1c8368a22",
        "tenantTerm": "Bus",
        "defaultTerm": "Bus",
        "id": "6c1b7d6f-42ee-46aa-ac88-1dcb6aff97a1"
    },
    {
        "masterNomenclatureId": "d4628654-9fa7-4951-81ce-b21bf07794d7",
        "tenantTerm": "Credit Card",
        "defaultTerm": "Credit Card",
        "id": "ce24c7cc-4028-4a28-8bd6-ad69de199d02"
    },
    {
        "masterNomenclatureId": "d4a879a4-c90b-40f3-b6c2-0e8d10825eec",
        "tenantTerm": "Invoiced Post Trip",
        "defaultTerm": "Invoiced Post Trip",
        "id": "41fe69b5-1eed-4035-be43-85e283d51202"
    },
    {
        "masterNomenclatureId": "d92982f8-5f7f-4c6b-ad17-d8b6d8475d1a",
        "tenantTerm": "Mrs",
        "defaultTerm": "Mrs",
        "id": "4a8c2c53-927b-4218-bb60-95f119da0932"
    },
    {
        "masterNomenclatureId": "d9495322-c9d4-4296-876d-c5b11acc6d8f",
        "tenantTerm": "Lump-Sum",
        "defaultTerm": "Lump-Sum",
        "id": "25349909-a412-4726-b013-cc28efb9ba6d"
    },
    {
        "masterNomenclatureId": "df4516af-51d5-4928-ad3f-46d8455c6f0c",
        "tenantTerm": "Debit Card",
        "defaultTerm": "Debit Card",
        "id": "549c1dac-c9ab-4a5c-a96b-8be47e4a9618"
    },
    {
        "masterNomenclatureId": "ea46d2bd-8a48-446d-806e-7c5de20c6d05",
        "tenantTerm": "Corporate",
        "defaultTerm": "Corporate",
        "id": "ff21e00a-4ea0-4509-9197-0f2ea59e02a6"
    },
    {
        "masterNomenclatureId": "edd13121-7f11-4ac8-940c-7a9e84c5f6df",
        "tenantTerm": "Day",
        "defaultTerm": "Day",
        "id": "664a3923-9abd-439b-8c31-0957b1c183d1"
    },
    {
        "masterNomenclatureId": "f098fb15-2b9e-4b97-8c57-bf7b8ad44171",
        "tenantTerm": "Fixed",
        "defaultTerm": "Fixed",
        "id": "ebba44bb-b570-403b-82ba-b7cea6fe079a"
    },
    {
        "masterNomenclatureId": "fa462662-444b-4e47-b64f-8932a1e7cd4f",
        "tenantTerm": "Debit Card",
        "defaultTerm": "Debit Card",
        "id": "0ded16ab-45ec-4e52-9bc4-af28e3d827eb"
    }
]


// for(const item of term){
//     // console.log(item);
//     const key  = item.defaultTerm
//     console.log(key);
// }
// let updateNomenClatureValues = {};
// for (const element of term) {
//     updateNomenClatureValues = {
//       ...updateNomenClatureValues,
//       [`${element.defaultTerm}`.replace(/ /g, '')]: element.defaultTerm,
//     };
//   }

//   console.log(updateNomenClatureValues)

  const dayOptions = [{
    label: 'Mon',
    value: '1',
  }, {
    label: 'Tue',
    value: '2',
  }, {
    label: 'Wed',
    value: '3',
  }, {
    label: 'Thu',
    value: '4',
  }, {
    label: 'Fri',
    value: '5',
  }, {
    label: 'Sat',
    value: '6',
  }, {
    label: 'Sun',
    value: '0',
  }];

  const daysOfWeeks = [
    {
        dayOfWeeks: [
            4
        ],
        "startTime": "08:00:39.3170000",
        "endTime": "09:00:39.3170000",
        "deletedByUser": false,
        "id": "3a975748-e94a-465b-82c5-e030783af15d"
    },
    {
        dayOfWeeks: [
            1
        ],
        "startTime": "09:00:39.3170000",
        "endTime": "10:00:39.3170000",
        "deletedByUser": false,
        "id": "f199b0cc-8a87-4d68-9a53-899807474434"
    }
]

  const getDaysOfWeek = (daysOfWeeks) => {
    const days = [];
    for (const day of daysOfWeeks) {
        // console.log(day);
      const result = dayOptions.find((option) => option.value === String(day));
      days.push(result);
    }
    console.log('days: ', days);
    return days;
  };

  getDaysOfWeek(daysOfWeeks)

  const operationalDays =  [
    {
        dayOfWeeks: [
            4
        ],
        startTime: "08:00:39.3170000",
        endTime: "09:00:39.3170000",
        deletedByUser: false,
        id: "3a975748-e94a-465b-82c5-e030783af15d"
    },
    {
        dayOfWeeks: [
            1
        ],
        startTime: "09:00:39.3170000",
        endTime: "10:00:39.3170000",
        deletedByUser: false,
        id: "f199b0cc-8a87-4d68-9a53-899807474434"
    }
]

const getFlattenOperationsValues = (operationalDays) => {
    const flatten = {};
    for (const [key, element] of operationalDays.entries()) {
        console.log(element);
      flatten[`operationalDays${element.id}`] = getDaysOfWeek(element.dayOfWeeks);
    //   flatten[`operationServiceTime${element.id}`] = {
    //     from: timeFormatter(element?.startTime),
    //     to: timeFormatter(element?.endTime),
    //   };
    //   flatten[`deletedByUser${element.id}`] = element.deletedByUser;
    //   flatten[`id${element.id}`] = element.id;
    }
    console.log('flatten', flatten);
  
    return flatten;
  };

  getFlattenOperationsValues(operationalDays);
  