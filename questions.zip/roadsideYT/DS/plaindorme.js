// palindromre number

// input x = 121 ---> true
//input x = 10 ---> false

const isPalindorm = (x) => {
    return x === +x.toString().split('').reverse().join('')
}
console.log('palindromre', isPalindorm(121))