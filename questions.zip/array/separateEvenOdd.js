// [0,24,1,2, 4,5,25,75,3,56,32, 8,3,45,67,0,7]
// [0,1, event, odd, ]

function evenOdd(numArray) {
let combinedArray = [];
let evenArray=[];
let oddArray=[];
for (let i=0; i<numArray.length; i++){
    if (numArray[i] === 0 || numArray[i] === 1){
        combinedArray.push(numArray[i]);
    }else if (numArray[i] % 2===0){
        evenArray.push(numArray[i]);
    }else if (numArray[i] % 2 !== 0){
        oddArray.push(numArray[i]);
    }

}
console.log('combined: ' + combinedArray);
console.log('evenArray: ' + evenArray);
combinedArray.push(...evenArray, ...oddArray);
return combinedArray;
}

console.log(evenOdd([0,24,1,2,4,5,25,75,3,56,32, 8,3,45,67,0,7]))