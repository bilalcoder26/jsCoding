//bubble sort (n-1) iterates 
//compare adjacent elements
const arr = [56,1,2,4,0,-1,89,8,7,10,11]

function bubbleSort(numArray) {
    for (let i = 0; i < numArray.length; i++){
        // console.log(`in outer loop index ${i} ${numArray[i]}`)

        for (let j = 0; j < numArray.length -i - 1; j++){
        // console.log(`in inner loop index ${j} ${numArray[j]}`)
        if(numArray[j] > numArray[j+1]){
            [numArray[j], numArray[j+1]] = [numArray[j+1], numArray[j]]
        }
            
        }
    }
return numArray
}

console.log(bubbleSort(arr));