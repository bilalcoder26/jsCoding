// Input: arr[] = [1, 2, 3, 5]
// Output: 4
// Explanation: All the numbers from 1 to 5 are present except 4.
// Input: arr[] = [8, 2, 4, 5, 3, 7, 1]
// Output: 6
// Explanation: All the numbers from 1 to 8 are present except 6.
// Input: arr[] = [1]
// Output: 2
// Explanation: Only 1 is present so the missing element is 2.

function findMissing(numArry){
    if(!numArry.length) return ;
    let min = Math.min(...numArry)
    let max= Math.max(...numArry)
    // console.log('min', min, max)
    let result = [];
    for(let i=min; i<max;i++){
        if(numArry.indexOf(i) < 0){
            result.push(i)
        }

    }
    return result

}

// console.log(findMissing([1, 2, 3, 8]))
// console.log(findMissing([8, 2, 4, 5, 3, 7, 1]))
// console.log(findMissing([1]))

// betterway

function findMissingNum(numArray){
    if(!numArray.length) return ;
    let min = Math.min(...numArray)
    let max= Math.max(...numArray)
    let missingNum = [];
    const numSet = new Set(numArray);
    // console.log('newSet', newSet);
    for (let i = min; i <= max; i++) {
        console.log('index', i, 'num', numSet)
        if (!numSet.has(i)) { // Check if the number is not in the Set
            missingNum.push(i);
        }
    }
    return missingNum;

}

console.log(findMissingNum([1, 2, 3, 8]))
// console.log(findMissingNum([8, 2, 4, 5, 3, 7, 1]))
// console.log(findMissingNum([1]))