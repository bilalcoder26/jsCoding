const array = [1, 1, 1, 2, 2, 2, 3, 3, 4, 4, 4, 4, 5, 5, 6, 6, 7, 7];
[1,2,3,4,5,6,7]
output =7;

function totalCountUnique(numArray) {
    if (!numArray.length) return ;
    let newArray = [];
    for (let i = 0; i < numArray.length; i++){
        for (let j = i +1; j < numArray.length; j++){
            if(numArray[i] === numArray[j]){
                newArray.push(numArray[j]);
                i++;
                j++
            }

        }
    }
    return newArray.length

}

console.log(totalCountUnique(array));