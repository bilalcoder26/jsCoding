const array = [-5,-4,-3,-2,-1,0,1,3,4,6,8];
output=[-4,4]

function checkSumZero(numArray) {
    let leftIndex =0;
    let rightIndex = numArray.length -1;
   while(leftIndex < rightIndex){
    const sum = numArray[leftIndex] + numArray[rightIndex];
    if(sum === 0){
        return [numArray[leftIndex], numArray[rightIndex]]
    } else if(sum <0){
        leftIndex++
    }else{
        rightIndex--
    }
   }
   return null;
}

console.log(checkSumZero(array));

