//[1,2,3,4,3,5,4,6,7,8] total element =10;
//count the largest sum of consecutive digits

//nums = 4;
//sums =25;

// formula = total element + num -1
// 10+4 -1

function consecutiveSum(numArray,num) {
    if(num > numArray.length || !numArray.length) return;
    let maxSum = 0;
    for(let i = 0; i < numArray.length-num +1; i++){
        let temp =0;
        for(let j=0; j< num; j++){
            // console.log(`i: ${i}, j: ${j}`)
            temp = temp + numArray[i+j];
        }
        if(temp > maxSum) maxSum = temp;

    }
    return maxSum;


}
//O(n)2
// console.log(consecutiveSum([1,2,3,4,3,5,4,6,7,8],4))

//sliding window technique linear time complexite

function consecutiveSum2(numArray, num) {
    if (num > numArray.length || !numArray.length) return;
    
    // Calculate the sum of the first 'num' elements
    let maxSum = 0;
    for (let i = 0; i < num; i++) {
        maxSum += numArray[i];
    }
    // console.log('max sum: ' + maxSum)
    
    let currentSum = maxSum;

    // Slide the window across the array
    for (let i = num; i < numArray.length; i++) {
        console.log('i: ' + i)
        currentSum = currentSum - numArray[i - num] + numArray[i];
        console.log('current sum: ' + currentSum)
        maxSum = Math.max(maxSum, currentSum);
    }

    return maxSum;
}

console.log(consecutiveSum2([1, 2, 3, 4, 3, 5, 4, 6, 7, 8], 4));
