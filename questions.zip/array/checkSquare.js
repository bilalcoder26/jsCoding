/**
 * check square in another array
 * arr1 =[1,2,3,4] arr2=[1,4,9,16]
 */
function isSquare(arr1, arr2) {
    for (let i = 0; i < arr1.length; i++) {
        let isSquare = false;
        for (let j = 0; j < arr2.length; j++) {
            if (arr1[i] * arr1[i] === arr2[j]) {
                isSquare = true;
                break; // Exit the inner loop as we found a match
            }
        }
        if (!isSquare) {
            return false; // If no square found, return false
        }
    }
    return true; // All elements in arr1 have their squares in arr2
}

// o(n)2 

// console.log(isSquare([1, 2, 3, 4], [1, 4, 9, 16])); // true
// console.log(isSquare([1, 2, 3, 5], [1, 4, 9, 16])); // false

function isSquare2(arr1, arr2) {
    let map1 ={};
    let map2 ={};

    for(let item1 of arr1){
        map1[item1] = (map1[item1] || 0 ) + 1;
    }
    for(let item2 of arr2){
        map2[item2] = (map2[item2] || 0 ) + 1;
    }
    console.log(map1, map2);
    for(let key in map1){
        console.log(key);
        if(!map2[key * key]){
            return false;
        }
        if(map1[key] !== map2[key * key]){
            return false;
        }
    }
    return true



}
console.log(isSquare2([1, 2, 3, 4], [1, 4, 9, 16]));
// console.log(isSquare2([1, 2, 3, 5], [1, 4, 9, 16])); 