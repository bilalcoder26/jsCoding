const arr = [56,1,2,4,0,-1,89,8,7,10,11]
// [0,-1,1,2,4,7,8,10,11,56,89]

function sorting(numArray) {
    if (!numArray.length) return;
    for(let i = 0; i < numArray.length; i++) {
        // console.log(`in outer loop index ${i} ${numArray[i]}`)
        for(let j = i+ 1; j < numArray.length; j++) {
        // console.log(`in inner loop index ${j} ${numArray[j]}`)
        if(numArray[i] > numArray[j]){
            [numArray[i], numArray[j]] = [numArray[j] , numArray[i]]
        }

        }
    }
    return numArray


}

console.log(sorting(arr));

/*
this approach is bubble-sort
The time complexity of this sorting algorithm is 
𝑂(𝑛2)
O(n 2) because of the nested loops.
*/