let input = [-2,1,-3,4,-1,2,1-5,4]
let output = 6;

function maxSumSubArr(){
    
}