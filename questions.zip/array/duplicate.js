const numArray = [1, 3, 4, 5, 63, 3, 3, 2, 3, 4, 3];

// Create an object to store the counts
const countDuplicates = {};

// Iterate through the array and count occurrences
for (let i = 0; i < numArray.length; i++) {
  const num = numArray[i];
  
  // If the number is already in the countDuplicates object, increment its count
  if (countDuplicates[num]) {
    countDuplicates[num]++;
  } else {
    // Otherwise, add the number with a count of 1
    countDuplicates[num] = 1;
  }
}
console.log('countDuplicates: ', countDuplicates)

// Find duplicates and their counts
const duplicates = [];
for (const num in countDuplicates) {
  if (countDuplicates[num] > 1) {
    duplicates.push({ num: num, count: countDuplicates[num] });
  }
}

console.log(duplicates);
