/*
write a table pass a number and return a table of that number and  
pass upto what length table should return
*/

function writeTable(num, times){
    if(num <=0 || times <= 0) return
    let table = [];
    for(let i=1; i<=times; i++){
        table.push(num * i)
    }
    return table

}

console.log("Writing a table", writeTable(2,10))
console.log("Writing a table", writeTable(3,10))