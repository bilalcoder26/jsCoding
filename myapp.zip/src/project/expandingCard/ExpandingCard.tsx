import "./style.css"
import brownMountain from '../assets/brownMountain.jpg';
import greenBlue from '../assets/greenBlue.jpg';
import goldenNature from '../assets/goldenNature.jpg';
import waterMountain from '../assets/waterMountain.jpg';
import whiteMountain from '../assets/whiteMountain.jpg';
import { useState } from "react";

const ExpandingCard = () => {
    const [activeIndex, setActiveIndex] = useState(0);

    const images = [
      { src: brownMountain, alt: "brown" },
      { src: greenBlue, alt: "green" },
      { src: goldenNature, alt: "golden" },
      { src: waterMountain, alt: "water" },
      { src: whiteMountain, alt: "white" },
    ];
  return (
    <div className="container">
        <div className="imgContainer">
        {images.map((image, index) => (
          <div
            key={index}
            className={`image-wrapper ${activeIndex === index ? "expanded" : ""}`}
            onClick={() => setActiveIndex(index)}
          >
            <img src={image.src} alt={image.alt} className="image" />
          </div>
        ))}
      </div>
       
    </div>
  )
}

export default ExpandingCard