import React, { useRef } from 'react'

const RefHook = () => {
    const countRef = useRef(0);
    const handleClick= ()=>{
        countRef.current++;
    console.log(`Clicked ${countRef.current} times`);

    }
    console.log('I rendered!');
  return (
    <div>
        <h1>
        refHook
        </h1>
        <button onClick={handleClick}>click</button>
    </div>
  )
}

export default RefHook;