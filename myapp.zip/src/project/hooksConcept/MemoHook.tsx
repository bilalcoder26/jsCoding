import { useState, useMemo,useEffect } from "react"

function slowFunction(number: number){
  console.log("slow function");
  for(let i = 0; i < 1000000000; i++){
    // console.log("i", i, number)
  }
  return number *2 ;

}

const MemoHook = () => {
  const [number, setNumber] = useState<number>(0);
  const [dark, setDark] = useState<boolean>(false);
  const doubleNumber = useMemo(()=> {
    return slowFunction(number)
  },[number])
  const themeStyle = useMemo(()=>{
    return {
      backgroundColor: dark ? 'black' : 'white',
      color: dark ? 'white' : 'black'

    }
   
  },[dark])
  useEffect(() => {
    console.log("theme style")
    
  }, [themeStyle])
  
  return (
    <div>
      <h1>memoHook</h1>
      <input 
      type="number" 
      value={number} 
      onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNumber(parseInt(e.target.value))} />
      <button onClick={()=> setDark(previousDark => !previousDark)}>changeTheme</button>
      <div style={themeStyle}>{doubleNumber}</div>
    </div>
  )
}

export default MemoHook