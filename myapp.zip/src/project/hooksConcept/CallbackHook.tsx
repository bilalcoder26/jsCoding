import React, { useCallback, useState } from 'react'
import List from './List';



const CallbackHook = () => {
    const [number, setNumber] = useState<number>(0);
    const [dark, setDark] = useState<boolean>(false);
    const themeStyle = {
        backgroundColor: dark ? 'black' : 'white',
        color: dark ? 'white' : 'black'
  
      }
    const getItems =useCallback(()=>{
        return [number,number+1, number+2]
      },[number])
  return (
    <div style={themeStyle}>
    <h1>useCallbackhook</h1>
    <input 
    type="number" 
    value={number} 
    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNumber(parseInt(e.target.value))} />
    <button onClick={()=> setDark(previousDark => !previousDark)}>changeTheme</button>
    <List getItems={getItems} />
  </div>
  )
}

export default CallbackHook