import React, { useEffect, useState } from "react";
import "./style.css"
const AutoTextEffect: React.FC = () => {
  const careers: string[] = ["YouTuber", "Web Developer", "Freelancer", "Instructor"];
  const [careerIndex, setCareerIndex] = useState(0);
  const [characterIndex, setCharacterIndex] = useState(0);
  const [careerText, setCareerText] = useState("");

  const updateText = () => {
    setCharacterIndex((prevCharacterIndex) => prevCharacterIndex + 1);
    setCareerText(
      `
      <h1>I am ${
        careers[careerIndex].slice(0, 1) === "I" ? "an" : "a"
      } ${careers[careerIndex].slice(0, characterIndex + 1)}</h1>
      `
    );

    if (characterIndex === careers[careerIndex].length) {
      setCareerIndex((prevCareerIndex) => (prevCareerIndex + 1) % careers.length);
      setCharacterIndex(0);
    }
  };

  useEffect(() => {
    const timer = setTimeout(updateText, 400);
    return () => clearTimeout(timer);
  }, [characterIndex, careerIndex]);

  return (
    <div className="container">
      <div dangerouslySetInnerHTML={{ __html: careerText }} />
    </div>
  );
};

export default AutoTextEffect;
