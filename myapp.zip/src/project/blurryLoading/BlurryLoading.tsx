import "./style.css"
import brownMountain from '../assets/brownMountain.jpg';
import { useEffect, useState } from "react";


const BlurryLoading = () => {
    const [loadPercentage, setLoadPercentage] = useState(0);
    useEffect(() => {
        const interval = setInterval(() => {
          setLoadPercentage((prev) => {
            if (prev < 100) {
              return prev + 1;
            } else {
              clearInterval(interval);
              return 100;
            }
          });
        }, 30); // Adjust the speed of the increment here (30ms per step)
      }, []);
    
      const blurValue = 30 - (loadPercentage / 100) * 30; // Calculates blur value decreasing 
  return (
    <div className="container">
        <img
        src={brownMountain}
        alt="Mountain"
        className="image"
        style={{ filter: `blur(${blurValue}px)` }}
      />
      {
        loadPercentage !== 100 && (
            <div className="loading-text">{loadPercentage}%</div>
        )
      }
    </div>
  )
}

export default BlurryLoading