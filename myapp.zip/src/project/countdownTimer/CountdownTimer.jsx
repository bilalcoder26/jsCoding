import "./style.css";
import { useState } from "react";
const CountdownTimer = () => {
  const [isTimerStart, setTimerStart] = useState(false);
  const [counter, setCounter] = useState({
    hours:0,
    minutes:0,
    seconds:0,
  })
  const onStart = () => {
    setTimerStart(true);
  };

  const onReset =()=>{
    setTimerStart(false);
  }
  const handleChange =(e)=> {
    let value = e.target.value
    
    if(e.target.name === 'hours'){
        console.log('hsdvbkjsdbvkjsdbvkjsdb')
        console.log('value', value)
        setCounter(value);
    }else if(e.target.name === 'minutes'){
        setCounter(value);
    }else if(e.target.name === 'seconds'){
        setCounter(value);
    }

  }
  console.log('counter changed hours', counter?.hours)
  console.log('counter changed min', counter?.minutes)
  console.log('counter changed sec', counter?.seconds)
  return (
    <div className="container">
      <h1 className="heading">Countdown Timer</h1>

      {isTimerStart ? (
        <>
          <div className="startTimer">
            <div>{counter.hours}</div>
            <span>:</span>
            <div>{counter.minutes}</div>
            <span>:</span>
            <div>{counter.seconds}</div>
          </div>
          <div className="groupBtn">
            <button className="btn">Pause</button>
            <button className="btn" type="button" onClick={onReset}>Reset</button>
          </div>
        </>
      ) : (
        <div className="timer">
          <div className="inputContainer">
            <input type="number" placeholder="HH" name="hours" onChange={handleChange}/>
            <span>:</span>
            <input type="number" placeholder="MM" name="minutes" onChange={handleChange}/>
            <span>:</span>
            <input type="number" placeholder="SS" name="seconds" onChange={handleChange}/>
          </div>
          <div>
            <button className="btn" type="button" onClick={onStart}>
              Start
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default CountdownTimer;
