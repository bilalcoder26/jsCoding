import { useState } from "react";
import "./style.css";

function AnimatedSearchBar() {
    const[active, setActive] = useState<boolean>(false);
    return (
        <div className='app'>
            <div className={active ? 'search-bar-container active' : ' search-bar-container'  }  
                onClick={()=> setActive(current => !current)}>
                <img
                    src="https://cdn4.iconfinder.com/data/icons/evil-icons-user-interface/64/magnifier-512.png"
                    alt="magnifier"
                    className="magnifier"
                />
                <input type="text" className="input" placeholder="Search ..." />
                <img
                    src="https://cdn1.iconfinder.com/data/icons/google-s-logo/150/Google_Icons-25-512.png"
                    alt="mic-icon"
                    className="mic-icon"
                />
            </div>
        </div>

    )
}

export default AnimatedSearchBar