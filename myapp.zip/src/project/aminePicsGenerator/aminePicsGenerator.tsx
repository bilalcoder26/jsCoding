import React, { useState } from 'react';
import "./style.css";

const AminePicsGenerator: React.FC = () => {
  const [buttonText, setButtonText] = useState<string>('Get Anime');
  const [isLoading, setIsLoading] = useState(false);
  const [data, setData] = useState({
    url: 'https://c.files.bbci.co.uk/F382/production/_123883326_852a3a31-69d7-4849-81c7-8087bf630251.jpg',
    artist: 'Anime Name'
  })
  const handleAnime = async (event: { currentTarget: { disabled: boolean; }; }) => {
    setIsLoading(true);
    setButtonText("Loading...");
    try {
      const response = await fetch("https://api.catboys.com/img", {
        method: 'GET',
        headers: {
          Accept: 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error(`Error! status: ${response.status}`);
      }
      const result = await response.json();
      console.log('result is: ', JSON.stringify(result, null, 4));
      setData(result);
    } catch (err) {
      // setErr(err.message);
    } finally {
      // setIsLoading(false);
    }
    setTimeout(() => {
      setIsLoading(false);
      setButtonText('Get Anime');
    }, 2000);

  }
  return (
    <div className='app'>
      <div className='conatiner'>
        <h3>AminePicsGenerator</h3>
        <button className='btn' onClick={handleAnime} disabled={isLoading}>{buttonText}</button>
        <div className="anime-container">
          <img className="anime-img"
            src={data.url}
            alt="alt" />
          <h3 className="anime-name">{data.artist}</h3>
        </div>
      </div>
    </div>

  );
};

export default AminePicsGenerator;

