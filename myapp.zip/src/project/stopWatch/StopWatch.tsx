import React, { useEffect, useRef, useState } from 'react'

const StopWatch = () => {
    const timerIdRef = useRef<ReturnType<typeof setInterval> | number>(0);
    const [count, setCount] = useState(0);
    const onStart = () =>{
        if (timerIdRef.current) return
        timerIdRef.current = setInterval(() => setCount((c)=> c + 1), 1000);
    }
    const onStop = () => {
        if (timerIdRef.current) {
            clearInterval(timerIdRef.current as NodeJS.Timeout);
            timerIdRef.current = 0;
        }
    };
    const onReset = () => {
      // timerIdRef.current = setInterval(() => setCount(0), 1000);
      setCount(0);
      clearInterval(timerIdRef.current as NodeJS.Timeout);
      timerIdRef.current = 0;

    }
    useEffect(() => {
      return () => clearInterval(timerIdRef.current);
    }, []);
  return (
    <div>
     <h1>StopWatch</h1>
     <h5>count:{count}</h5>
     <button onClick={onStart}>start</button>   
     <button onClick={onStop}>stop</button>   
     <button onClick={onReset}>reset</button>   
    </div>
  )
}

export default StopWatch