import React, { useEffect, useRef } from 'react'

const InputFocus = () => {
    const inputRef = useRef<HTMLInputElement | null>(null);
    useEffect(() => {
        if (inputRef.current) {
            inputRef.current.focus();
        }
    }, []);
    console.log(inputRef.current);
  return (
    <div>
    <h1> InputFocus</h1>   
    <input type="text" ref={inputRef} />
    </div>
  )
}

export default InputFocus;