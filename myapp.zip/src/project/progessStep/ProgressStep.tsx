import { useState } from "react";
import "./style.css";

const ProgressStep = () => {
    const step = [1, 2, 3, 4];
    // const activeStep = 2; // Set the current active step (1-indexed)
    const [activeStep, setActiveStep] = useState(1);
    const handlePrevious = () => {
        if (activeStep > 1) {
            setActiveStep(activeStep - 1);
        }
    };

    const handleNext = () => {
        if (activeStep < step.length) {
            setActiveStep(activeStep + 1);
        }
    };

    return (
        <div className="container">
            <div className="stepper">
                {step.map((s, index) => (
                    <div className="stepWrapper" key={s}>
                        <div
                            className={`circle ${index + 1 <= activeStep ? "active" : ""}`}
                        >
                            <span className="circleText">{s}</span>
                        </div>
                        {index < step.length - 1 && (
                            <div
                                className={`horizontalPipe ${
                                    index + 1 < activeStep ? "filled" : ""
                                }`}
                            ></div>
                        )}
                    </div>
                ))}
            </div>
            <div className="buttons">
                <button 
                className="button" 
                disabled={activeStep === 1}
                type="button"
                onClick={handlePrevious}>
                Pre
                </button>
                <button 
                className="button"
                disabled={activeStep === step.length}
                onClick={handleNext}
                >Next</button>
            </div>
        </div>
    );
};

export default ProgressStep;
