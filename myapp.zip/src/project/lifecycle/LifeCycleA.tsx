import React, { Component } from 'react'
import LifeCycleB from './LifeCycleB'

 class LifeCycleA extends Component {
    constructor(props:any) {
      super(props)
    
      this.state = {
         name: 'Bilal',
      }
      console.log('LifeCycleA constructor')
    }

    static getDerivedStateFromProps(props:any, state:any){
        console.log('lifeCycleA.getDerivedStateFromProps')
        return null
    }
    componentDidMount(): void {
        console.log('lifeCycleA.componentDidMount')
    }
  render() {
    console.log('lifeCycleA.render')
    return (
      <div>
        LifeCycleA
        <LifeCycleB />
    </div>
    )
  }
}

export default LifeCycleA
