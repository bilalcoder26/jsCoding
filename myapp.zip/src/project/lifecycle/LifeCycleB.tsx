import React, { Component } from 'react'

 class LifeCycleB extends Component {
    constructor(props:any) {
      super(props)
    
      this.state = {
         name: 'Bilal',
      }
      console.log('lifeCycleB constructor')
    }

    static getDerivedStateFromProps(props:any, state:any){
        console.log('lifeCycleB.getDerivedStateFromProps')
        return null
    }
    componentDidMount(): void {
        console.log('lifeCycleB.componentDidMount')
    }
  render() {
    console.log('lifeCycleB.render')
    return (
      <div>lifeCycleB</div>
    )
  }
}

export default LifeCycleB
