import React from 'react';
import BlurryLoading from './project/blurryLoading/BlurryLoading';
import Todo from './project/todoProject/TodoApp';
import TodoApp from './project/todoProject/TodoApp';
import LifeCycleA from './project/lifecycle/LifeCycleA';
import CountdownTimer from './project/countdownTimer/CountdownTimer';
// import ProgressStep from './project/progessStep/ProgressStep';
// import ExpandingCard from './project/expandingCard/ExpandingCard';
// import StopWatch from './project/stopWatch/StopWatch';
// import InputFocus from './project/stopWatch/InputFocus';
// import MemoHook from './project/hooksConcept/MemoHook';
// import CallbackHook from './project/hooksConcept/CallbackHook';
// import RefHook from './project/hooksConcept/refHook';
// import LogButtonClicks from './project/hooksConcept/LogButtonClicked';
// import AutoTextEffect from './project/autoTextEffect/AutoTextEffect';
// import AnimatedSearchBar from './project/animatedSearchBar/animatedSearchBar';
// import AminePicsGenerator from './project/aminePicsGenerator/aminePicsGenerator';

const App: React.FC = () => {
  return (
    <div>
      {/* <AminePicsGenerator/> */}
      {/* <AnimatedSearchBar /> */}
      {/* <AutoTextEffect /> */}
      {/* <MemoHook /> */}
      {/* <CallbackHook /> */}
      {/* <RefHook /> */}
      {/* <LogButtonClicks /> */}
      {/* <StopWatch /> */}
      {/* <InputFocus /> */}
      {/* <ExpandingCard /> */}
      {/* <ProgressStep /> */}
      {/* <BlurryLoading /> */}
      {/* <TodoApp /> */}
      {/* <LifeCycleA /> */}
      <CountdownTimer />

    </div>
  );
};

export default App;

