const fs = require('fs');
const os = require('os');

//sync

// fs.writeFileSync('./test.txt', 'hey workds ') 

//async
// fs.writeFile('./test2.txt', 'hey asynchronous ',() =>{});
// const result = fs.readFileSync('./contact.txt', 'utf-8');
// console.log(result);

// fs.readFile('./contact.txt', 'utf-8',(err, result)=>{
//     if(err){
//         console.log(err);
//     }else{
//         console.log(result);
//     }

// });
// fs.appendFileSync('test2.txt',`${Date.now()} hey there\n` )
// fs.mkdirSync('mydocs')
console.log(os.cpus().length);