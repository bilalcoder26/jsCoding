const http  = require('http');
const fs = require('fs');
const  url  = require('url');

const express = require('express');
const app = express();
app.get('/', (req, res) =>{
    return res.send("hello from  hOME PAGE")

});

app.get('/about', (req, res) =>{
    return res.send(`hello from  About PAGE ${req.query.name}`)

});
app.listen(8000,() => console.log('listening on 8000'));

// const myServer = http.createServer(app)

// const myServer = http.createServer((req, res) => {
//     if(req.url === '/favicon.ico') return res.end();
//     const log  =`${Date.now()} : ${req.url} New Req Recived\n`
//     const myUrl = url.parse(req.url);
//     console.log(myUrl);
//     fs.appendFile("log.txt",log,(err, data) => {
//         // res.end("Hello from the server!! again")
//         switch(req.url){
//             case '/':
//                 res.end("Home page");
//              break
//             case "/contact":
//                 res.end (" i am Bilal Ahmed")
//              break
//             default:
//                 res.end("Please choose your path  correctly")
//         }

//     })
// })

// myServer.listen(8000, () => console.log('server listening on 8000 port'));
// console.log('sdvsdv')