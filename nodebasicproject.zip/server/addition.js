const math = require('./math');
console.log(math.add(4,5));
console.log(math.sub(4,5));