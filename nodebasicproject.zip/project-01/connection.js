const mongoose = require('mongoose');

async function connectMongoDB(url, option){
    return mongoose.connect(url, option);
// .then(() => console.log('Mongoose connection established'))
// .catch((err) => console.log('Mongo Error: ' + err));
}

module.exports = {
    connectMongoDB
}