const { query } = require('express');
const User  = require('../models/user');
const { ObjectId} = require('mongodb')
async function handleGetAllUsers(req, res){
    const allUsers = await User.find({})
    return res.json(allUsers);

}
async  function handleGetUserById(req, res){
     const user = await User.findById(req.params.id);
     if(!user) return res.status(404).json({error: 'Not Found'});
 
     return res.json(user);
}

// async function handleUpdateUserById(req, res){
//     const id = req.params.id
//     const body = req.body;
//     const query = {_id: new ObjectId(id)}
//     const updateDoc = {$set:{...body}}
//     // await User.findByIdAndUpdate(req.params.id, {lastName: 'changed'})
//     await User.updateOne(query, updateDoc)
//     return res.json({status: 'updated sucessfully'});
// }

async function handleUpdateUserById(req, res) {
    try {
        const id = req.params.id; // Assuming this is a string
        const body = req.body;

        // Ensure `id` is a valid ObjectId string
        if (!ObjectId.isValid(id)) {
            return res.status(400).json({ error: 'Invalid ObjectId format' });
        }

        const query = { _id: new ObjectId(id) };
    console.log('query ', query );

        const updateDoc = { $set: { ...body } };
        console.log('update doc ', updateDoc);

        // Perform the update operation
        await User.updateOne(query, updateDoc);

        return res.json({ status: 'Updated successfully' });
    } catch (error) {
        return res.status(500).json({ error: 'Something went wrong', details: error.message });
    }
}

async function handleDeleteUserById(req, res){
    await User.findByIdAndDelete(req.params.id);
    return res.json({status: 'Sucess'});
}

async function handleCreateUser(req, res){
    // console.log('req', req);
    // const body = {
    //     "firstName": "maheshe",
    //     "lastName": "dalal rastogh",
    //     "email": "dala@yopmail.com",
    //     "gender": "male",
    //     "jobTitle": "chess"
    // }
    const body = req.body;
    if(!body || !body.firstName || !body.lastName || !body.email || !body.jobTitle){
        return res.status(404).json({message:"all fileds are required"});
    }
   const result = await User.create({
        firstName: body.firstName,
        lastName: body.lastName,
        email: body.email,
        gender: body.gender,
        jobTitle: body.jobTitle
    })
    console.log('result:', result);
    return res.status(201).json({msg:'success'})
}

module.exports = {
    handleGetAllUsers,
    handleGetUserById,
    handleUpdateUserById,
    handleDeleteUserById,
    handleCreateUser,
}