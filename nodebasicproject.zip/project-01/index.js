const express = require('express');
const {connectMongoDB} = require('./connection')
const {logReqRes} = require('./middlewares');
const userRouter = require('./routes/user');
// const users = require('./MOCK_DATA.json');
// const fs = require('fs');
// const mongoose = require('mongoose');

const app = express();

const PORT = 8000;

const dbURL = "mongodb+srv://admin:MongoDB%40717718@auth.gq8bg.mongodb.net/?retryWrites=true&w=majority&appName=auth"
const dbOptions =  {
    // useNewUrlParser: true,
    // useUnifiedTopology: true,
    authSource:"admin",
    ssl: true,
}

//connection
connectMongoDB(dbURL, dbOptions)
.then(() => console.log('Mongoose connection established'))
.catch((err) => console.log('Mongo Error: ' + err))

app.use(express.urlencoded({ extended:false }));
app.use(express.json());

//middleware
app.use(logReqRes('log.txt'))

//Routes
app.use("/api/users", userRouter);

app.listen(PORT, () => console.log('server started'));